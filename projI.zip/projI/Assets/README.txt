The Game:
You are a bat. Try to survive as long as possible by avoiding hawks and buildings. 

-You are the green halo
-the particles emenating from you are your flight direction and sonar direction

-hawks are red halos
-the red stream is the hawk's flight direction

Controls and mechanics:
-you move forward automatically
-you will turn towards the mouse
-you will periodically emit sonar in the direction you are looking.
-this will create marks in the world
-holding space or leftMouseBtn will zoom in and slow time

-hawks will chase you
-if a hawk touches you, you will die
-if you crash into a building or ground, you will die
-if a hawk crashes into a building, it will die

-try to trick hawks into crashing into buildings
-the more hawks you kill, the higher level you will reach

-once you kill a wave, you will spawn away from the buildings with more hawks
-try to get to the highest level possible

Strategy:
Try to go towards the buildings. The white halo marks the origin point(0, 0, 0).
Hawks move faster than you but turn slower. Let them get close and swirve out of
the way at the last moment. Use bullet time to help you perform this maneuvre.
Once at the buildings, hide behind them to make hawks crash.








